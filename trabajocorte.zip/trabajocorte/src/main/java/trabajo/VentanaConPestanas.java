package trabajo;

import javax.swing.*;
import java.awt.*;

public class VentanaConPestanas extends JFrame {
    public VentanaConPestanas() {
        setTitle("Interfaz con Pestañas");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel panel1 = new PilaPanel();
        tabbedPane.addTab("Pestaña 1 (Pila)", panel1);

        JPanel panel2 = new ListaNombresPanel();
        tabbedPane.addTab("Pestaña 2 (Nombres)", panel2);

        JPanel panel3 = new ColaTiendaPanel();
        tabbedPane.addTab("Pestaña 3 (Cola)", panel3);

        JPanel panel4 = new ArbolBinarioPanel();
        tabbedPane.addTab("Pestaña 4 (Árbol Binario)", panel4);

        add(tabbedPane, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new VentanaConPestanas().setVisible(true);
        });
    }
}
