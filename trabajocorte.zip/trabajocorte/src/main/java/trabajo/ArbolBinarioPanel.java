package trabajo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ArbolBinarioPanel extends JPanel {
    private class Node {
        int value;
        Node left, right;
        int x, y; 

        public Node(int value) {
            this.value = value;
            left = right = null;
        }
    }

    private Node root;               
    private JTextField campoTexto;   
    private JButton botonInsertar;   

    public ArbolBinarioPanel() {
        setLayout(new BorderLayout());

        
        JPanel panelEntrada = new JPanel();
        campoTexto = new JTextField(5);
        botonInsertar = new JButton("Insertar");
        panelEntrada.add(new JLabel("Valor:"));
        panelEntrada.add(campoTexto);
        panelEntrada.add(botonInsertar);
        add(panelEntrada, BorderLayout.NORTH);

        botonInsertar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int valor = Integer.parseInt(campoTexto.getText().trim());
                    root = insertar(root, valor);
                    campoTexto.setText("");
                    repaint();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(ArbolBinarioPanel.this, "Ingrese un número entero válido.");
                }
            }
        });
    }

    private Node insertar(Node nodo, int valor) {
        if (nodo == null) {
            return new Node(valor);
        }
        if (valor < nodo.value) {
            nodo.left = insertar(nodo.left, valor);
        } else if (valor > nodo.value) {
            nodo.right = insertar(nodo.right, valor);
        }
        return nodo;
    }

    private int asignarPosiciones(Node nodo, int x, int y) {
        if (nodo == null) return x;
        x = asignarPosiciones(nodo.left, x, y + 50);
        nodo.x = x;
        nodo.y = y;
        x += 50;  
        x = asignarPosiciones(nodo.right, x, y + 50);
        return x;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        asignarPosiciones(root, 20, 70);
        dibujarArbol(g, root);
    }

    private void dibujarArbol(Graphics g, Node nodo) {
        if (nodo == null) return;

        if (nodo.left != null) {
            g.drawLine(nodo.x + 15, nodo.y + 15, nodo.left.x + 15, nodo.left.y + 15);
            dibujarArbol(g, nodo.left);
        }

        if (nodo.right != null) {
            g.drawLine(nodo.x + 15, nodo.y + 15, nodo.right.x + 15, nodo.right.y + 15);
            dibujarArbol(g, nodo.right);
        }

        g.setColor(Color.CYAN);
        g.fillOval(nodo.x, nodo.y, 30, 30);
        g.setColor(Color.BLACK);
        g.drawOval(nodo.x, nodo.y, 30, 30);
        g.drawString(String.valueOf(nodo.value), nodo.x + 10, nodo.y + 20);
    }
}
