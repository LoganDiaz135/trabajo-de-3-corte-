package trabajo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import java.util.Stack;

public class PilaPanel extends JPanel {
    private Stack<String> pila;
    private DefaultListModel<String> modeloLista;
    private JList<String> lista;
    private JTextField campoTexto;
    private Random random;

    public PilaPanel() {
        pila = new Stack<>();
        modeloLista = new DefaultListModel<>();
        lista = new JList<>(modeloLista);
        campoTexto = new JTextField(10);
        random = new Random();

        setLayout(new BorderLayout());

        JPanel panelEntrada = new JPanel();
        JButton botonPush = new JButton("añadir");
        JButton botonPop = new JButton("eliminar");
        JButton botonGenerar = new JButton("Generar Aleatorio");

        botonPush.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String elemento = campoTexto.getText().trim();
                if (!elemento.isEmpty()) {
                    pila.push(elemento);
                    actualizarLista();
                    campoTexto.setText("");
                }
            }
        });

        botonPop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!pila.isEmpty()) {
                    pila.pop();
                    actualizarLista();
                } else {
                    JOptionPane.showMessageDialog(PilaPanel.this, "La pila está vacía", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        botonGenerar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int numeroAleatorio = random.nextInt(10);
                pila.push(String.valueOf(numeroAleatorio));
                actualizarLista();
            }
        });

        panelEntrada.add(new JLabel("Elemento:"));
        panelEntrada.add(campoTexto);
        panelEntrada.add(botonPush);
        panelEntrada.add(botonPop);
        panelEntrada.add(botonGenerar);

        add(panelEntrada, BorderLayout.NORTH);
        add(new JScrollPane(lista), BorderLayout.CENTER);
    }

    private void actualizarLista() {
        modeloLista.clear();
        for (int i = pila.size() - 1; i >= 0; i--) {
            modeloLista.addElement(pila.get(i));
        }
    }
}
