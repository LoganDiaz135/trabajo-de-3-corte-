package trabajo;

import javax.swing.*;
import java.awt.*;

public class ListaNombresPanel extends JPanel {
    public ListaNombresPanel() {
        setLayout(new BorderLayout());
        
        String[] nombres = {"Juan", "María", "Pedro", "Ana", "Luis", "Sofía"};
        
        JList<String> listaNombres = new JList<>(nombres);
        listaNombres.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(listaNombres);
        
        add(scrollPane, BorderLayout.CENTER);
    }
}

