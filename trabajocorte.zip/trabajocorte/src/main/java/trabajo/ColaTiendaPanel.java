package trabajo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import java.util.Queue;

public class ColaTiendaPanel extends JPanel {
    private Queue<String> cola;
    private DefaultListModel<String> modeloLista;
    private JList<String> lista;
    private JTextField campoTexto;

    public ColaTiendaPanel() {
        cola = new LinkedList<>();
        modeloLista = new DefaultListModel<>();
        lista = new JList<>(modeloLista);
        campoTexto = new JTextField(10);

        setLayout(new BorderLayout());

        JPanel panelEntrada = new JPanel();
        JButton botonAgregar = new JButton("Agregar Cliente");
        JButton botonAtender = new JButton("Atender Cliente");

        botonAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cliente = campoTexto.getText().trim();
                if (!cliente.isEmpty()) {
                    cola.offer(cliente); // agrega al final de la cola
                    actualizarLista();
                    campoTexto.setText("");
                }
            }
        });

        botonAtender.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!cola.isEmpty()) {
                    String atendido = cola.poll();
                    JOptionPane.showMessageDialog(ColaTiendaPanel.this, "Cliente atendido: " + atendido);
                    actualizarLista();
                } else {
                    JOptionPane.showMessageDialog(ColaTiendaPanel.this, "La cola está vacía", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        panelEntrada.add(new JLabel("Cliente:"));
        panelEntrada.add(campoTexto);
        panelEntrada.add(botonAgregar);
        panelEntrada.add(botonAtender);

        add(panelEntrada, BorderLayout.NORTH);
        add(new JScrollPane(lista), BorderLayout.CENTER);
    }

    private void actualizarLista() {
        modeloLista.clear();
        for (String cliente : cola) {
            modeloLista.addElement(cliente);
        }
    }
}
